package com.sports.major.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sports.major.model.Role;

public interface RoleRepository extends JpaRepository<Role, Integer> {

}
